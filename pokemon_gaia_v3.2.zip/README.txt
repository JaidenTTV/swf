=== POK�MON GAIA VERSION v3.2 =================================================
Base ROM: 	1635 - Pokemon Fire Red (U)(Squirrels) [1636 should work too!]
Language: 	English
Version:	3.2
Released:	8th November, 2018
Thread:		http://www.pokecommunity.com/showthread.php?t=326118
			https://reliccastle.com/threads/77/
Discord:	https://discordapp.com/invite/NpayHay

v3.2 is a bugfix update for v3.
Please scroll down for a changelog, as well as more bugs which have not yet
been fixed.

Saves from v3.0 and v3.1 ARE compatible with v3.2.

However, as with v3.0, saves from versions v2.5 or before of Gaia are NOT
compatible with v3.2.

=== LOCATIONS AND INFO ========================================================
Beware, spoilers!
� Pok�mon locations: http://bit.ly/GaiaPokemonLocations
	� Also includes the list of unobtainable Pok�mon
� Item locations: http://bit.ly/GaiaItemLocations
	� Also includes Mega Stone locations and TM/HM locations
� Changed evolution methods: http://bit.ly/GaiaEvolutionMethods
� Shard Move Tutor moves: http://bit.ly/GaiaMoveTutors

To play, download a FireRed ROM and apply the .UPS patch to the .GBA file using
the included NUPS program.
Visit the thread(s) linked above for a more in- depth patching guide, and for
other operating systems (Android, etc.).

v3 ends after the credits roll, and so includes all eight Gyms, and the Elite
Four and Champion battles.

There is a planned v4.0, which will include the postgame for Gaia.
Saves from v3.0, v3.1 and v3.2 are planned to be forwards-compatible with v4.0.

=== CHANGE LOG ================================================================
� Rename Edamist Steppes to Edamist Heights to better reflect its geography

� Change the road block in Aerous Road
    - As some Trainers are available earlier, Fernando's Pok�mon have been
	raised a few levels
	- Similarly, the wilds in Aerous Road are slightly lower
	- The first two Trainers in Aerous Road are also slightly lower
	- The Super Potion in the bare spot of grass is now a Potion
	- The Painter in Aerous Road also shows up in the queue and indoors of
	the Aerous Art Club

� Change the New Elders encounter in Frostbite Cave to be less of an ambush
    - The player is not forced directly into battles with the Grunt and
	Elder Knight Eunice
	- The battles are instead initiated when the player tries to talk to
	Eunice or walk past her
	- Some of the dialog was rewritten
	- The map was made slightly smaller to make it clearer that this is the
	exit of Frostbite Cave

� Change the Braille puzzle's hint in Ferre Ruins to be less cryptic

� Change the events in Precimos Island so it is (hopefully) more clear where to
go after defeating the Gym

� Make Hidden Power display its type for the Pok�mon it is being taught to,
or known by

� Fix the softlock state in the Atsail City Gym which may occur if the player
whites out when the puzzle is in a certain state.

� Fix the combination lock input box occasionally showing up to 7 digits, when
only 4 are needed

� Fix the impassible tiles outside of Redwood's house in Archan Town

� Fix Cranidos' evolution method, so it actually evolves into Rampardos

� Fix Pok�mon with inconsistent level-up rates, which causes them to gain
levels upon evolution
    - Porygon-Z
	- Greninja

� Fix Rotom's compatibility with TM34, Shock Wave

� Fix Bisharp's compatibility with Sucker Punch from the Green Shard Meister

� Fix Maractus' incorrect weight

� Fix Mienshao's Ability order so that Mienfoo does not swap its Ability when
evolving

� Fix the reflection tile errors in Cosmic Caverns

� Fix the reflection tile errors in Nestpine Town

� Fix a plethora of bugged icon sprites

� Give the Pok�mon with no Ability the following Abilities:
    - Mega Glalie: Refrigerate
	- Mega Ampharos: Lightningrod

� Make the textboxes of Coulter and Prof. Redwood actually disappear after they
are finished speaking in Redwood's house

� Fix the text colour inconsistencies with the Diving Tour lady's dialog in the
cutscene in Precimos Depths

� Fix Coulter's Surfing Pok�mon blob still showing up in Precimos Depths after
the cutscene takes place

� Fix the Escape Rope's warp location for Wisp Forest and Rimewood Forest

� Fix the border error in Nestpine Climb
	
� Fix Empoleon's EXP yield

� Fix the persistent money HUD after refusing to sell anything to the Relic
Collector in the Precimos Hotel

� Fix the palette for HM01 Cut to match its Bug-type

� Fix the missing TM/HM compatibility for the following Pok�mon's female forms:
	- Frillish
	- Jellicent
	- Pyroar

� Fix the incorrect battle background in the Telmurk City house where the Mightyena
Thug is battled

� Fix the incorrect script assigned to the right statue in the Nestpine Gym

� Fix some tiles in Cosmic Caverns not spawning wild Pok�mon

� Fix Hidden Power's text description

� Fix Boomburst making contact

� Fix Ace Trainer Arnie's incorrect encounter music in Victory Falls

� Fix Deoxys' overworld sprite not disappearing

� Fix Crunch's description implying it lowers the foe's Sp. Def, when it only
lowers Defense

� Fix some tiles in Ignis Catacombs which display incorrectly when the fog
weather effect is active

� Fix Eevee and Flareon's erroneous compatibility with TM18 Aurora Beam

� Fix the movement permission errors in Telmurk Swamp

� Move Ace Trainer Elnora so she challenges the player regardless of the
direction she is facing in Ikos Canyon

� Fix some tiles in Cosmic Cavern which are not covered by the player

� Fix Beheeyem's catch rate of 0

� Fix Pidgey and Zubat's erroneously high experience yields

� Fix Grass Knot's base power displaying at 20 when it should be --

� Fix Leafeon's bugged Pok�dex entry string

� Fix the Snover and Budew evolution lines' incompatibilities with TM09,
Energy Ball

� Fix Sgt. Stone giving out Venusaurite when shown a Blastoise

� Fix Pidgeotite being unobtainable
	- [N.B. Players who already picked up a Pidgeotite will be able to pick it
	up again now]

� Fix the Cut trees in Sabulo Cross appearing hidden when the route is entered
via Sabulo Island

� Fix some tiles in Valoon Way which are erroneously covered by the player

� [STORY SPOILER] Fix the errors caused by the player being on their Bicycle when
activating the New Elders event in Sabulo Island

� Fix Roserade's inability to re-learn Weather Ball from Mrs. Move
